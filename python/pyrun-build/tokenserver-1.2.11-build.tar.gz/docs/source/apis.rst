APIS
====

.. cornice-autodoc::
   :modules: tokenserver.views
   :service: token
