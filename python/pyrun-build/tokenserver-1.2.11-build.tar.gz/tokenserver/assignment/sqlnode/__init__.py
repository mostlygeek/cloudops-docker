from tokenserver.assignment.sqlnode.sql import SQLNodeAssignment  # NOQA
